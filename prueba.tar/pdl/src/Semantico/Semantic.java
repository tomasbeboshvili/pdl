package Semantico;
public class Semantic {
	
}
