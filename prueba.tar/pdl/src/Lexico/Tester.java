package Lexico;

import Sintactico.Parser;
import Sintactico.ASTNode;

import java.io.*;
import java.util.List;

public class Tester {
    public static void main(String[] args) {
        try {
            // 💣 LIMPIAR carpeta de salida
            File outputDir = new File("salida_tests");
            if (outputDir.exists() && outputDir.isDirectory()) {
                for (File file : outputDir.listFiles()) {
                    if (!file.isDirectory()) {
                        file.delete();
                    }
                }
            }

            // 1. Leer archivo de entrada
            BufferedReader reader = new BufferedReader(new FileReader("entrada_tests/test1.txt"));
            StringBuilder input = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                input.append(line).append("\n");
            }
            reader.close();

            // 2. Generar tokens
            Lexer lexer = new Lexer(input.toString());
            List<Token> tokens = lexer.tokenize();

            // 3. Ejecutar parser y generar AST
            Parser parser = new Parser(tokens);
            ASTNode ast = parser.parseAST();

            // 4. Guardar árbol sintáctico en .txt (formato .dot pero extensión .txt)
            BufferedWriter dotWriter = new BufferedWriter(new FileWriter("salida_tests/test1_ast.txt"));
            dotWriter.write(ast.toDotFile());
            dotWriter.close();

            // 5. Guardar tabla de símbolos
            parser.exportarTS("salida_tests/test1_tabla_simbolos.txt");

            System.out.println("✅ AST y TS generados correctamente.");

        } catch (IOException e) {
            System.err.println("❌ Error de archivo: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }
}
